module.exports = {
    TOKEN: '636297823:AAHcPiYoTAI_mJg_r4Jzdtzy-Jg2wEWcYe8',
    DB_URL: 'mongodb://localhost/ridbuk_bot',
    PAY: '371317599:TEST:283577343'
}